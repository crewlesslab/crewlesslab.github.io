# Resume Builder — Private, Offline, Single-File Resume Maker

Thank you for downloading! This is a tiny, private, no-subscription resume builder:
**one HTML file** that runs entirely in your browser. No sign-up, no job-site account,
no tracking — **your resume data never leaves your browser.**

Made by **Crewless Lab** — an AI-operated studio. https://www.crewlesslab.com

---

## Quick Start

1. Unzip the download.
2. Double-click `resume-en.html`. It opens in your default browser (Chrome, Edge,
   Firefox and Safari all work).
3. Fill in the form on the left — the resume preview on the right updates live.
4. Click **Print / Save PDF** and choose "Save as PDF" as the destination.

That's it. There is nothing to install.

> Tip: keep the file somewhere permanent (e.g. your Documents folder) and open it
> from there every time, so your saved data stays with it.

## What It Does

- **Two templates** — *Classic* (single column, serif headings, timeless) and
  *Compact* (sidebar layout that fits more on a page). Switch with one click in
  the preview toolbar; your data is never touched.
- **All the standard sections** — Contact (with two links for portfolio/LinkedIn/GitHub),
  Summary, Work Experience, Education, Skills, and optional Certifications.
- **Reorderable sections** — move Skills above Experience for a skills-first resume,
  or push Education to the bottom. Arrow buttons on each section card.
- **Achievement bullets** — write one accomplishment per line; they become clean
  bullet points on the resume.
- **Skills as tags** — type a comma-separated list, get neat skill tags.
- **Version management** — save one version per kind of role ("Design lead roles",
  "Acme application"), then switch or duplicate in the **Versions** dialog.
  Tailoring your resume per application is the single highest-leverage job-search
  habit, and this makes it painless.
- **ATS-aware output** — the printed resume is a plain top-to-bottom text flow with
  no table layout. The Compact template automatically collapses to a single column
  in print so applicant tracking systems can parse it cleanly.
- **1–2 page output** on both A4 and US Letter paper.
- **JSON backup** — export everything to a file and import it on another machine.

## Where Is My Data?

Everything is stored in your browser's `localStorage`, on your computer only.
Nothing is uploaded anywhere — the file makes zero network requests.

Because of that, two things to know:

- Data is tied to **this browser on this computer**. Use **Export** to move it
  (or to make a backup before clearing browser data).
- If you clear your browser's site data, the tool's data is cleared too.

## Saving a PDF

Use the **Print / Save PDF** button and select "Save as PDF" in your browser's
print dialog. The layout fits both A4 and US Letter in one or two pages with no
scaling needed. The suggested filename is generated from your name
(e.g. `Alex Morgan_Resume.pdf`).

## Version Workflow (recommended)

1. Build your "master" resume with everything in it.
2. Press **Save** and give it a label like `Master`.
3. For each application: open **Versions**, click **Duplicate** on the master,
   trim it to what that role cares about, relabel it, and **Save**.
4. Print / Save PDF. Repeat for the next application.

## Keyboard Shortcut

- `Ctrl + S` (Mac: `Cmd + S`) — save the current version.

## FAQ

**Does it work offline?**
Yes, completely. It is a single self-contained HTML file.

**Is the output ATS-friendly?**
The printed PDF is real selectable text in a linear flow — no tables, no images,
no columns in print. That is the format parsing software handles best. (No tool
can guarantee any specific ATS, but this avoids the known pitfalls.)

**Can I use it on a phone or tablet?**
Yes — the layout switches to an Edit / Preview tab view on narrow screens.
Printing is best done from a desktop browser.

**Can I edit the file?**
Sure — it's plain HTML/CSS/JavaScript with comments. Make a copy first.

**Want to see it filled in?**
Open the file with `#sample` added to the address (e.g.
`resume-en.html#sample`) in a browser where you haven't entered data yet, and a
fictional example resume is loaded. It never overwrites your own work.

## License

Personal and commercial use permitted (i.e. use it to apply for any job, or build
resumes for your clients). Redistribution or resale of the file itself is not
permitted.

## Support

Found a bug or have a feature request? Contact us through the store page where
you got this file, or via https://www.crewlesslab.com

---

Version 1.0.0 — Made by Crewless Lab, an AI-operated studio.
